var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_url = require("url");
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_meta = {};
import_dotenv.default.config();
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
var exerciseDatabase = [];
var exerciseImageIndex = /* @__PURE__ */ new Map();
function normalizeExerciseName(name) {
  return (name || "").toLowerCase().replace(/[-_/]/g, " ").replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim();
}
try {
  const raw = import_fs.default.readFileSync(import_path.default.join(__dirname, "data", "exercises-min.json"), "utf-8");
  exerciseDatabase = JSON.parse(raw);
  exerciseDatabase.forEach((ex) => {
    if (ex.name && ex.images?.length) {
      exerciseImageIndex.set(normalizeExerciseName(ex.name), ex.images);
    }
  });
} catch (err) {
  console.warn("Kon exercises-min.json niet laden, AI valt terug op vrij genereren:", err);
}
var EXERCISE_IMAGE_BASE_URL = "https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/";
function findExerciseImages(exerciseName) {
  const normalized = normalizeExerciseName(exerciseName);
  if (!normalized) return void 0;
  const exact = exerciseImageIndex.get(normalized);
  if (exact) return exact;
  let bestMatch = null;
  for (const [dbNameNorm, images] of exerciseImageIndex.entries()) {
    let score = 0;
    if (dbNameNorm.includes(normalized) || normalized.includes(dbNameNorm)) {
      score = Math.min(normalized.length, dbNameNorm.length);
    } else {
      const stem = (w) => w.endsWith("es") ? w.slice(0, -2) : w.endsWith("s") && w.length > 3 ? w.slice(0, -1) : w;
      const aiWords = new Set(normalized.split(" ").map(stem));
      const dbWords = dbNameNorm.split(" ").filter((w) => w.length > 2).map(stem);
      const overlap = dbWords.filter((w) => aiWords.has(w)).length;
      if (dbWords.length > 0 && overlap >= 2 && overlap / dbWords.length >= 0.5) {
        score = overlap;
      }
    }
    if (score > 0 && (!bestMatch || score > bestMatch.score)) {
      bestMatch = { images, score };
    }
  }
  return bestMatch?.images;
}
function enforcePrescribedWeights(exercises, prescribedWeights) {
  if (!Array.isArray(exercises) || Object.keys(prescribedWeights).length === 0) return exercises;
  return exercises.map((ex) => {
    const key = (ex?.name || "").toLowerCase().trim();
    if (key && prescribedWeights[key] !== void 0) {
      return { ...ex, targetWeight: prescribedWeights[key] };
    }
    return ex;
  });
}
function enrichExercisesWithImages(exercises) {
  if (!Array.isArray(exercises)) return exercises;
  return exercises.map((ex) => {
    const images = ex?.name ? findExerciseImages(ex.name) : void 0;
    if (images && images.length > 0) {
      const fullUrls = images.map((img) => EXERCISE_IMAGE_BASE_URL + img);
      return { ...ex, imageUrl: fullUrls[0], images: fullUrls };
    }
    return ex;
  });
}
function normalizeSessionName(name) {
  return (name || "").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, "").replace(/\s+/g, " ").trim();
}
function sessionNamesMatch(a, b) {
  const na = normalizeSessionName(a);
  const nb = normalizeSessionName(b);
  return !!na && !!nb && na === nb;
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  let aiClient = null;
  function getGeminiClient(userApiKey) {
    const key = userApiKey || process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is niet ingesteld. Voeg deze toe in Settings > Secrets of in je profiel.");
    }
    if (!aiClient || userApiKey) {
      aiClient = new import_genai.GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
    }
    return aiClient;
  }
  function isQuotaError(err) {
    if (!err) return false;
    const errString = typeof err === "string" ? err : (err.message || "") + " " + (err.status || "") + " " + JSON.stringify(err);
    return errString.includes("429") || errString.includes("quota") || errString.includes("QUOTA") || errString.includes("limit") || errString.includes("exhausted") || errString.includes("RESOURCE_EXHAUSTED") || err.status === "RESOURCE_EXHAUSTED" || err.code === 429;
  }
  function summarizeRecentIntensity(history) {
    const counts = { Makkelijk: 0, Perfect: 0, Maximaal: 0 };
    (Array.isArray(history) ? history : []).forEach((session) => {
      (session?.exercises || []).forEach((ex) => {
        if (ex?.intensity && counts[ex.intensity] !== void 0) {
          counts[ex.intensity]++;
        }
      });
    });
    const total = counts.Makkelijk + counts.Perfect + counts.Maximaal;
    if (total === 0) {
      return { text: "Nog geen intensiteit-data beschikbaar.", dominant: "onbekend" };
    }
    let dominant = "Perfect";
    if (counts.Maximaal / total > 0.5) dominant = "Maximaal";
    else if (counts.Makkelijk / total > 0.5) dominant = "Makkelijk";
    return {
      text: `Laatste sessies gerapporteerd: ${counts.Maximaal}x Maximaal, ${counts.Perfect}x Perfect, ${counts.Makkelijk}x Makkelijk.`,
      dominant
    };
  }
  function computeDeloadWeek(baseline) {
    if (!baseline?.completedAt) return false;
    const weeksSince = Math.floor(
      (Date.now() - new Date(baseline.completedAt).getTime()) / (7 * 24 * 60 * 60 * 1e3)
    );
    return weeksSince > 0 && weeksSince % 6 === 0;
  }
  function computeBlockNumber(baseline, referenceTimestamp) {
    if (!baseline?.completedAt) return 1;
    const reference = referenceTimestamp || Date.now();
    const weeksSince = Math.floor(
      (reference - new Date(baseline.completedAt).getTime()) / (7 * 24 * 60 * 60 * 1e3)
    );
    return Math.floor(Math.max(0, weeksSince) / 4) + 1;
  }
  function computeProgressedWeight(previousWeight, previousIntensity, recentIntensities) {
    if (!previousWeight || previousWeight <= 0) return previousWeight;
    if (recentIntensities && recentIntensities.length >= 2 && recentIntensities.slice(0, 2).every((i) => i === "Makkelijk")) {
      return Math.round(previousWeight * 1.1 * 2) / 2;
    }
    if (previousIntensity === "Makkelijk") return Math.round(previousWeight * 1.05 * 2) / 2;
    if (previousIntensity === "Maximaal") return previousWeight;
    return Math.round(previousWeight * 1.025 * 2) / 2;
  }
  function computeNumberOfExercises(duration, goal) {
    const safeDuration = duration && duration > 0 ? duration : 60;
    const g = (goal || "").toLowerCase();
    let setsPerExercise = 3.5;
    let avgRestSeconds = 75;
    if (g.includes("kracht") || g.includes("power")) {
      setsPerExercise = 3.5;
      avgRestSeconds = 150;
    } else if (g.includes("herstel") || g.includes("vitaliteit")) {
      setsPerExercise = 2.5;
      avgRestSeconds = 37.5;
    } else if (g.includes("vetverlies") || g.includes("conditie")) {
      setsPerExercise = 3;
      avgRestSeconds = 30;
    }
    const timePerSetSeconds = 45;
    const transitionBufferSeconds = 60;
    const timePerExerciseSeconds = setsPerExercise * (timePerSetSeconds + avgRestSeconds) + transitionBufferSeconds;
    const warmupMinutes = 8;
    const availableMinutes = Math.max(10, safeDuration - warmupMinutes);
    const raw = Math.round(availableMinutes * 60 / timePerExerciseSeconds);
    return Math.min(12, Math.max(2, raw));
  }
  function buildGoalRule(goal, numberOfExercises, equipment) {
    const g = (goal || "").toLowerCase();
    const equipList = Array.isArray(equipment) ? equipment.join(", ") : "";
    if (g.includes("kracht") || g.includes("power")) {
      return `
STRENGE VERPLICHTING VOOR DOEL 'MAXIMALE KRACHT':
        - Reps MOETEN tussen 3-5 liggen voor hoofdoefeningen.
        - Rusttijd tussen sets: 120-180 seconden (geef dit door als 'restSeconds').
        - Kies hogere intensiteit/gewicht boven hoog volume; 3-4 sets per oefening is voldoende.`;
    }
    if (g.includes("herstel") || g.includes("vitaliteit")) {
      return `
STRENGE VERPLICHTING VOOR DOEL 'HERSTEL & VITALITEIT':
        - Dit is GEEN lichtere hypertrofie-training \u2014 het doel is gewrichtsmobiliteit, houding en doorbloeding, niet spiergroei.
        - Prioriteer mobiliteit- en stabiliteitsoefeningen met een groot bewegingsbereik (bijv. rotator cuff work, hip mobility drills, lichte kabeloefeningen door de volledige range) boven zware compound-bewegingen.
        - Reps MOETEN tussen 12-20 liggen, met duidelijk lager gewicht dan gebruikelijk.
        - Rusttijd tussen sets: 30-45 seconden (geef dit door als 'restSeconds').
        - Houd het volume licht: 2-3 sets per oefening.`;
    }
    if (g.includes("vetverlies") || g.includes("conditie")) {
      return `
STRENGE VERPLICHTING VOOR DOEL 'VETVERLIES & CONDITIE':
        - Dit is GEEN krachttraining met kortere rust \u2014 minimaal 2 van de ${numberOfExercises} hoofdoefeningen MOETEN echte cardio/conditie-blokken zijn (bijv. 'HIIT op Loopband', 'Fietsergometer Intervallen', 'Rij-ergometer', 'Jumping Jacks Circuit'), gekozen uit de beschikbare apparatuur: ${equipList || "lichaamsgewicht-opties"}.
        - Voor deze cardio-blokken: 'reps' uitgedrukt als duur/intervallen (bijv. '10x 30s sprint / 30s rust', '15 minuten gematigd tempo'), targetWeight altijd 0, muscle 'Cardio'.
        - De OVERIGE oefeningen zijn krachtoefeningen met hoge reps (12-15), korte rust (20-40s, geef dit door als 'restSeconds'), als circuit-achtige aanvulling \u2014 geen zware compound-lifts.
        - 3 sets per oefening voor de krachtoefeningen is voldoende; prioriteer bewegingen die meerdere spiergroepen tegelijk belasten.`;
    }
    return `
STRENGE VERPLICHTING VOOR DOEL 'HYPERTROFIE':
        - Reps MOETEN tussen 8-12 liggen.
        - Rusttijd tussen sets: 60-90 seconden (geef dit door als 'restSeconds').
        - 3-4 sets per oefening is gebruikelijk.`;
  }
  function buildVolumeBudgetRule(metrics) {
    if (!metrics || typeof metrics !== "object") return "";
    const constrained = [];
    Object.entries(metrics).forEach(([muscle, info]) => {
      if (info && typeof info.ratio === "number" && info.ratio > 0.6) {
        const recoveryPct = Math.round((1 - info.ratio) * 100);
        constrained.push(`${muscle} (${recoveryPct}% herstel, ${info.rawSets || 0} recente sets)`);
      }
    });
    if (constrained.length === 0) return "";
    return `
STRENGE VERPLICHTING VOOR WEKELIJKS VOLUMEBUDGET:
        - Deze spiergroepen zitten al dicht bij hun volumegrens: ${constrained.join(", ")}.
        - Verlaag voor deze spiergroepen het aantal sets met minimaal 1 t.o.v. wat je anders zou voorstellen, of kies een lagere-belasting variant.
        - Geef binnen de toegestane spiergroep-selectie voorrang aan spieren met een hoger herstelpercentage.`;
  }
  function detectPlateaus(history, sessionName) {
    if (!Array.isArray(history)) return [];
    const matchingSessions = history.filter((s) => sessionNamesMatch(s?.name, sessionName)).slice(0, 3);
    if (matchingSessions.length < 3) return [];
    const plateaued = [];
    const candidateExercises = matchingSessions[0]?.exercises || [];
    candidateExercises.forEach((ex) => {
      if (!ex?.name) return;
      const allMaximaal = matchingSessions.every(
        (s) => (s?.exercises || []).some((e) => e?.name === ex.name && e?.intensity === "Maximaal")
      );
      if (allMaximaal) plateaued.push(ex.name);
    });
    return plateaued;
  }
  function estimateOneRM(weight, reps, knownOneRM) {
    if (knownOneRM && knownOneRM > 0) return Math.round(knownOneRM);
    const rawEstimate = weight / (1.0278 - 0.0278 * reps);
    return Math.round(rawEstimate * 0.9);
  }
  function estimateFirstSessionWeight(bodyWeight, liftType) {
    const safeBodyWeight = bodyWeight && bodyWeight > 0 ? bodyWeight : 75;
    const ratios = { push: 0.25, pull: 0.2, legs: 0.35, overhead: 0.15 };
    const raw = safeBodyWeight * ratios[liftType];
    return Math.max(5, Math.round(raw / 2.5) * 2.5);
  }
  function getMuscleCategoriesForFocus(sessionName) {
    const focus = (sessionName || "").toLowerCase();
    if (focus.includes("full body") || focus.includes("combinatie")) {
      return ["chest", "lats", "middle back", "shoulders", "quadriceps", "hamstrings", "biceps", "triceps", "abdominals"];
    }
    if (focus.includes("upper") || focus.includes("bovenlichaam")) {
      return ["chest", "lats", "middle back", "shoulders", "biceps", "triceps"];
    }
    if (focus.includes("lower") || focus.includes("benen") || focus.includes("legs")) {
      return ["quadriceps", "hamstrings", "calves", "glutes", "abductors", "adductors"];
    }
    if (focus.includes("push")) {
      return ["chest", "shoulders", "triceps"];
    }
    if (focus.includes("pull")) {
      return ["lats", "middle back", "lower back", "traps", "biceps", "forearms"];
    }
    if (focus.includes("borst") || focus.includes("chest")) {
      return ["chest"];
    }
    if (focus.includes("rug") || focus.includes("back")) {
      return ["lats", "middle back", "lower back", "traps"];
    }
    if (focus.includes("schouders") || focus.includes("shoulder")) {
      return ["shoulders"];
    }
    if (focus.includes("arm")) {
      return ["biceps", "triceps", "forearms"];
    }
    return ["chest", "lats", "shoulders", "quadriceps", "hamstrings", "biceps", "triceps", "abdominals"];
  }
  function getCandidateExercises(muscleCategories, userEquipment, category, limit = 20, requireMuscleMatch = true) {
    if (exerciseDatabase.length === 0) return [];
    const normalizedEquip = (Array.isArray(userEquipment) ? userEquipment : []).map((e) => e.toLowerCase());
    const equipmentMatches = (dbEquip) => {
      if (!dbEquip || dbEquip === "body only" || dbEquip === "other") return true;
      return normalizedEquip.some((e) => e.includes(dbEquip.toLowerCase()) || dbEquip.toLowerCase().includes(e));
    };
    if (!requireMuscleMatch || muscleCategories.length === 0) {
      const matches = exerciseDatabase.filter((ex) => ex.category === category && equipmentMatches(ex.equipment));
      return matches.slice(0, limit).map((ex) => ex.name);
    }
    const perCategoryLimit = Math.max(2, Math.ceil(limit / muscleCategories.length));
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const cat of muscleCategories) {
      const matches = exerciseDatabase.filter(
        (ex) => ex.category === category && ex.primaryMuscles.includes(cat) && equipmentMatches(ex.equipment) && !seen.has(ex.name)
      );
      matches.slice(0, perCategoryLimit).forEach((ex) => {
        seen.add(ex.name);
        result.push(ex.name);
      });
    }
    return result;
  }
  async function generateContentWithFallback(ai, options) {
    const models = [
      options.primaryModel || "gemini-3.5-flash",
      "gemini-3.5-flash",
      "gemini-flash-latest",
      "gemini-3.1-flash-lite"
    ];
    const uniqueModels = models.filter((item, pos) => models.indexOf(item) === pos);
    let lastError = null;
    for (const model of uniqueModels) {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          console.log(`[AURA AI] Calling generateContent with model: ${model} (attempt ${attempt})`);
          const response = await ai.models.generateContent({
            model,
            contents: options.contents,
            config: options.config
          });
          return response;
        } catch (err) {
          lastError = err;
          if (isQuotaError(err)) {
            console.log(`[AURA AI] Note: Quota limit reached for model ${model}. Attempting fallback to next available model...`);
            break;
          }
          console.log(`[AURA AI] Note: Model ${model} is currently busy or offline. Attempt ${attempt} completed.`);
          if (attempt < 2) {
            await new Promise((resolve) => setTimeout(resolve, 1e3 * attempt));
          }
        }
      }
    }
    throw lastError || new Error("Alle model-pogingen en fallbacks zijn mislukt.");
  }
  app.post("/api/gemini/insight", async (req, res) => {
    try {
      const { userModel, metrics, steps, history, userApiKey, isRestDay, sessionCompletedToday, nextSession, prefs, baseline } = req.body;
      const ai = getGeminiClient(userApiKey);
      const intensitySummary = summarizeRecentIntensity(history);
      const painNotes = Array.isArray(prefs?.painNotes) ? prefs.painNotes : [];
      const isDeloadWeekInsight = computeDeloadWeek(baseline);
      const weeksSinceBaseline = baseline?.completedAt ? Math.floor((Date.now() - new Date(baseline.completedAt).getTime()) / (7 * 24 * 60 * 60 * 1e3)) : null;
      let prompt = `Je bent Aura, de persoonlijke AI fitness coach van ${userModel.name || "Gebruiker"} (doel: ${userModel.goal || "Hypertrofie"}).
      WETENSCHAPPELIJKE REGEL: Lopen (stappen) is LISS cardio. Raad NOOIT af om benen te trainen vanwege wandelen! Wandelen = actief herstel. Alleen bij >12000 stappen mag je eventueel adviseren om het *volume* (aantal sets) licht te verlagen, maar kracht/intensiteit blijft nodig.`;
      if (sessionCompletedToday) {
        prompt += `
DE GEBRUIKER HEEFT VANDAAG EEN TRAINING SUCCESVOL VOLTOOID.
        - Feliciteer ze kort en enthousiast met de prestatie.
        - Geef wetenschappelijk onderbouwd advies voor herstel direct na de training (zoals eiwitsynthese, rehydratatie, herstelvoeding, spierpijn preventie of lichte stretching).
        - Benadruk dat de herstelfase nu is begonnen. Richten op rust voor spieropbouw.`;
      } else if (isRestDay) {
        prompt += `
VANDAAG IS EEN GEPLANDE RUSTDAG. Er staat geen workout gepland vandaag.
        - Geef de gebruiker uitsluitend wetenschappelijk onderbouwde tips voor optimaal herstel (zoals slaapkwaliteit, actieve mobiliteit, voeding of hydratatie).
        - Moedig ze NIET aan om vandaag naar de sportschool te gaan of te trainen. Benadruk dat rust essentieel is voor spiergroei en herstel.`;
      } else {
        prompt += `
VANDAAG IS EEN TRAININGSDAG voor de ${nextSession || "geplande split"}.
        - Geef een motiverend of voorbereidend inzicht om naar de sportschool te gaan en progressive overload te bereiken.`;
      }
      prompt += `
Logboek: ${JSON.stringify(history || [])}. Spierherstel percentages (0=kapot, 100=optimaal): ${JSON.stringify(metrics || {})}. Vandaag gezette stappen: ${steps || 0}.
      ${intensitySummary.text}`;
      if (intensitySummary.dominant === "Maximaal") {
        prompt += `
De gebruiker rapporteert overwegend MAXIMALE inspanning de laatste tijd. Erken dit kort en expliciet, en benoem dat extra rust/herstel deze week belangrijk is.`;
      } else if (intensitySummary.dominant === "Makkelijk") {
        prompt += `
De gebruiker rapporteert overwegend MAKKELIJKE sessies. Moedig vriendelijk aan om de volgende sessie iets uitdagender aan te pakken (zwaarder gewicht of meer herhalingen).`;
      }
      if (painNotes.length > 0) {
        prompt += `
GEMELDE PIJNPUNTEN/BLESSURES: ${painNotes.join(", ")}. Houd hier rekening mee in je advies en moedig NOOIT aan om door pijn heen te trainen.`;
      }
      if (isDeloadWeekInsight && weeksSinceBaseline !== null) {
        prompt += `
Dit is een deload-week (week ${weeksSinceBaseline} sinds de nulmeting) \u2014 een goed natuurlijk moment voor een eerlijke realiteitscheck. Geef naast je normale advies een kort, realistisch beeld van wat na ${weeksSinceBaseline} weken qua spieropbouw/kracht haalbaar is: natuurlijke hypertrofie is langzaam (circa 0,25-1% lichaamsgewicht per maand voor ervaren lifters, iets sneller in het eerste trainingsjaar). Vermijd overdreven enthousiasme of valse beloftes \u2014 wees eerlijk en geruststellend dat langzame, gestage progressie normaal en gezond is.`;
      }
      prompt += `
Geef in maximaal 3 zinnen een wetenschappelijk onderbouwd inzicht voor vandaag. Spreek de gebruiker rechtstreeks aan met 'je'. Geen markdown, geen opsommingen.`;
      const response = await generateContentWithFallback(ai, {
        contents: prompt,
        primaryModel: "gemini-3.5-flash",
        config: {
          temperature: 0.7
        }
      });
      res.json({ text: response.text });
    } catch (error) {
      console.log("[AURA AI] Notice: Biometric offline generator engaged. Delivering premium local biometrics guidance.");
      const { steps, isRestDay, sessionCompletedToday, nextSession } = req.body;
      const stepsCount = steps || 0;
      let fallbackText = "";
      if (sessionCompletedToday) {
        fallbackText = "Geweldige training vandaag! Je spieren hebben nu rust en herstelstoffen nodig om sterker te worden. Focus op eiwitrijke voeding, rehydratatie en minimaal 7-8 uur diepe slaap vanavond voor een optimale eiwitsynthese.";
      } else if (isRestDay) {
        fallbackText = "Vandaag is een geplande rustdag. Je spieren herstellen en groeien tijdens rust, niet tijdens de training. Focus op kwalitatieve voeding, actieve mobiliteit en voldoende slaap vanavond om je zenuwstelsel te ontlasten.";
      } else if (stepsCount > 12e3) {
        fallbackText = `Je bent vandaag zeer actief met ${stepsCount} stappen (actief herstel). Als je vandaag krachttraning doet (zoals benen), overweeg dan om je trainingsvolume met 10% te verminderen om centrale vermoeidheid te beperken.`;
      } else if (stepsCount > 5e3) {
        fallbackText = `Met ${stepsCount} stappen ben je vandaag goed in beweging! Dit stimuleert de doorbloeding, wat helpt bij het afvoeren van afvalstoffen en het herstellen van vermoeide spiervezels. Klaar voor je overload op ${nextSession || "je geplande split"}?`;
      } else {
        fallbackText = "Probeer vandaag nog wat actieve beweging te pakken om de bloedsomloop te stimuleren. Een korte wandeling van 15-20 minuten verhoogt de doorbloeding en versnelt het herstel van spierpijn van eerdere trainingen.";
      }
      res.json({ text: fallbackText, isFallback: true });
    }
  });
  app.post("/api/gemini/workout", async (req, res) => {
    try {
      const { userModel, metrics, history, prefs, sessionName, numberOfExercises: requestedExerciseCount, userApiKey, baseline, isRestDay } = req.body;
      const numberOfExercises = isRestDay ? requestedExerciseCount || 5 : computeNumberOfExercises(userModel.duration, userModel.goal);
      const ai = getGeminiClient(userApiKey);
      const isDeloadWeek = !isRestDay && computeDeloadWeek(baseline);
      const painNotes = Array.isArray(prefs?.painNotes) ? prefs.painNotes : [];
      const hasBaselineNumbers = !!(baseline && (baseline.benchPressWeight || baseline.squatWeight || baseline.latPulldownWeight || baseline.overheadPressWeight));
      let baselinePrompt = "";
      if (baseline && !isRestDay && hasBaselineNumbers) {
        baselinePrompt = `
GEBRUIKER NULMETING (BASELINE KRACHevaluatie):
        - Ervaringsniveau: ${baseline.experienceLevel || "Gematigd"}
        - Bench Press: werkset ${baseline.benchPressWeight || 50}kg voor ${baseline.benchPressReps || 8} reps (1RM: ${estimateOneRM(baseline.benchPressWeight || 50, baseline.benchPressReps || 8, baseline.benchPress1RM)}kg${baseline.benchPress1RM ? ", door gebruiker zelf opgegeven" : ", schatting met veiligheidsmarge"})
        - Back Squat: werkset ${baseline.squatWeight || 60}kg voor ${baseline.squatReps || 8} reps (1RM: ${estimateOneRM(baseline.squatWeight || 60, baseline.squatReps || 8, baseline.squat1RM)}kg${baseline.squat1RM ? ", door gebruiker zelf opgegeven" : ", schatting met veiligheidsmarge"})
        - Lat Pulldown / Row: werkset ${baseline.latPulldownWeight || 45}kg voor ${baseline.latPulldownReps || 8} reps (1RM: ${estimateOneRM(baseline.latPulldownWeight || 45, baseline.latPulldownReps || 8, baseline.latPulldown1RM)}kg${baseline.latPulldown1RM ? ", door gebruiker zelf opgegeven" : ", schatting met veiligheidsmarge"})
        - Overhead / Shoulder Press: werkset ${baseline.overheadPressWeight || 30}kg voor ${baseline.overheadPressReps || 8} reps (1RM: ${estimateOneRM(baseline.overheadPressWeight || 30, baseline.overheadPressReps || 8, baseline.overheadPress1RM)}kg${baseline.overheadPress1RM ? ", door gebruiker zelf opgegeven" : ", schatting met veiligheidsmarge"})
        
        STRENGE VERPLICHTING: Gebruik deze nulmeting als absolute schaalreferentie om startgewichten ('targetWeight') te bepalen voor alle gerelateerde spieren en oefeningen (bijv. bench press gewicht vertalen naar dumbbell press of pec-deck, squat gewicht vertalen naar leg press of extensions, enz.). Prescribeer nooit onrealistisch hoge of lage gewichten ten opzichte van deze baseline. Bij een "schatting met veiligheidsmarge" mag je de eerste paar sessies bewust iets aan de lichte kant blijven \u2014 de progressie-logica trekt dit snel bij zodra de gebruiker 'Makkelijk' rapporteert.`;
      } else if (!isRestDay && !hasBaselineNumbers) {
        const pushW = estimateFirstSessionWeight(userModel.weight, "push");
        const pullW = estimateFirstSessionWeight(userModel.weight, "pull");
        const legsW = estimateFirstSessionWeight(userModel.weight, "legs");
        const overheadW = estimateFirstSessionWeight(userModel.weight, "overhead");
        baselinePrompt = `
GEBRUIKER NULMETING: GEEN CIJFERS BESCHIKBAAR (DIT IS DE ECHTE EERSTE SESSIE).
        - Er is GEEN eerdere gewicht/reps-data, want iemand die nog nooit in een sportschool is geweest kan onmogelijk inschatten wat een 'werkgewicht' voor bench press of squat betekent. Dat is geen ontbrekende data, dat is bewust zo.
        - Onderstaande referentiegewichten zijn TOTAALGEWICHTEN voor een BARBELL-oefening (incl. de stang van ~20kg), geschaald op het lichaamsgewicht van de gebruiker (${userModel.weight || 75}kg): duwbewegingen ~${pushW}kg, trekbewegingen ~${pullW}kg, beenoefeningen ~${legsW}kg, overhead press ~${overheadW}kg.
        - KRITIEKE REKENREGEL VOOR ANDERE APPARATUUR (voorkom een veelgemaakte fout): 'targetWeight' bij DUMBBELL-oefeningen is het gewicht PER HAND, niet totaal \u2014 dus reken de barbell-referentie eerst om naar totaal-equivalent en deel dan door 2 (bijv. referentie 25kg totaal \u2192 dumbbells van ~10-12,5kg PER HAND, niet 25kg per hand). Bij MACHINES: kies bewust een lage, conservatieve stand, los van de referentiegetallen hierboven (machine-schalen verschillen te veel per merk om op dit lichaamsgewicht-getal te baseren).
        - KRITIEKE REGEL VOOR ISOLATIE-OEFENINGEN: bovenstaande referenties gelden alleen voor zware, samengestelde bewegingen (squat, bench press, deadlift, rij, overhead press). Voor isolatie-oefeningen (bijv. lateral raise, leg extension, bicep curl, triceps pushdown) gebruik je maximaal 30-40% van de relevante referentie \u2014 deze bewegen maar \xE9\xE9n gewricht en vragen dus veel minder gewicht, ook voor gevorderden.
        - Vermeld in de 'executionCue' van elke oefening expliciet dat dit een veilig startgewicht is dat wordt aangepast zodra je hebt getraind, niet een vast gewicht \u2014 bijv. "We beginnen licht zodat je de beweging leert; volgende keer passen we het gewicht aan op basis van hoe dit voelde."
        - Deze EERSTE sessie IS de eigenlijke nulmeting: vanaf de volgende sessie bepaalt de progressie-logica (op basis van gerapporteerde intensiteit) het juiste gewicht, niet een schattingsformule.`;
      }
      let muscleSplitRule = "";
      if (isRestDay) {
        const stretchCandidates = getCandidateExercises([], [], "stretching", 15, false);
        muscleSplitRule = `
STRENGE VERPLICHTING VOOR RUSTDAG (YOGA & ACTIEF HERSTEL):
        - VANDAAG IS EEN GEPLANDE RUSTDAG. De gebruiker moet YOGA en STRETCHING doen ter bevordering van spierherstel en flexibiliteit.
        - Je MOET uitsluitend YOGA, STRETCHING en MOBILITEITS-oefeningen aanbevelen.${stretchCandidates.length > 0 ? ` Kies bij voorkeur namen uit deze geverifieerde lijst: ${stretchCandidates.join(", ")}.` : " (bijv. Child's Pose, Downward-Facing Dog, Cobra Pose, Pigeon Pose, Cat-Cow Stretch, Savasana, Sphinx Pose, Happy Baby Pose, enz.)"}
        - Het startgewicht ('targetWeight') MOET voor alle oefeningen exact 0 zijn (lichaamsgewicht / yoga mat).
        - De apparatuur ('equip') MOET 'Lichaamsgewicht' of 'Yoga mat' zijn.
        - De 'reps' MOETEN worden uitgedrukt als duur of ademhalingen (bijv. '60s', '45s', '5 min').
        - De primaire spiergroep ('muscle') moet de gestretchte regio zijn (bijv. 'Onderrug', 'Hamstrings', 'Gluten', 'Rug', 'Core', 'Heupen').`;
      } else {
        const focus = (sessionName || "").toLowerCase();
        if (focus.includes("full body") || focus.includes("combinatie")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR FULL BODY:
          - Genereer een gevarieerde full body workout waarbij alle grote spiergroepen getraind worden.
          - Verdeel de ${numberOfExercises} hoofdoefeningen zo gelijk mogelijk over deze 5 categorie\xEBn: Borst, Rug (of Onderrug), Schouders, Benen (Quadriceps/Hamstrings/Gluten), Arm of Core (Biceps/Triceps/Kuiten/Core).
          - Doorloop ALLE 5 categorie\xEBn minstens \xE9\xE9n keer voordat je een categorie een TWEEDE keer kiest \u2014 pas bij meer dan 5 oefeningen mag een categorie dus opnieuw voorkomen. Bij minder dan 5 oefeningen: sla de categorie 'Arm of Core' als laatste over, niet Borst/Rug/Schouders/Benen.
          - Dit garandeert dat alle spiergroepen evenredig aan bod komen. Geen dubbele spiergroepen ten koste van anderen.`;
        } else if (focus.includes("upper") || focus.includes("bovenlichaam")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR UPPER BODY:
          - Gebruik UITSLUITEND oefeningen voor het bovenlichaam (Borst, Rug, Schouders, Biceps, Triceps).
          - Absoluut GEEN oefeningen voor onderlichaam of benen (zoals Quadriceps, Hamstrings, Gluten, Kuiten). Dit is een harde limiet!
          - Verdeel de ${numberOfExercises} oefeningen zo gelijk mogelijk over Borst, Rug, Schouders, Biceps en Triceps \u2014 doorloop ALLE 5 categorie\xEBn minstens \xE9\xE9n keer voordat een categorie een tweede keer voorkomt (mits ${numberOfExercises} \u2265 5; anders prioriteer Borst, Rug en Schouders boven Biceps/Triceps).`;
        } else if (focus.includes("lower") || focus.includes("benen") || focus.includes("legs")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR LOWER BODY / LEGS / BENEN:
          - Gebruik UITSLUITEND oefeningen voor het onderlichaam (Quadriceps, Hamstrings, Gluten, Kuiten).
          - Absoluut GEEN oefeningen voor het bovenlichaam (zoals Borst, Rug, Schouders, Biceps, Triceps). Dit is een harde limiet!
          - Verdeel de ${numberOfExercises} oefeningen zo gelijk mogelijk over Quadriceps, Hamstrings, Gluten en Kuiten \u2014 doorloop ALLE 4 categorie\xEBn minstens \xE9\xE9n keer voordat een categorie een tweede keer voorkomt (mits ${numberOfExercises} \u2265 4; anders prioriteer Quadriceps en Hamstrings boven Gluten/Kuiten).`;
        } else if (focus.includes("push")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR PUSH DAY:
          - Gebruik UITSLUITEND duwbewegingen van het bovenlichaam (Borst, Schouders, Triceps).
          - Absoluut GEEN trekbewegingen (Rug, Biceps) of benen (Quadriceps, Hamstrings, Gluten, Kuiten) in deze training!`;
        } else if (focus.includes("pull")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR PULL DAY:
          - Gebruik UITSLUITEND trekbewegingen van het bovenlichaam (Rug, Biceps, Onderrug).
          - Absoluut GEEN duwbewegingen (Borst, Schouders, Triceps) of pure quadriceps benen (Quadriceps, Kuiten) in deze training!`;
        } else if (focus.includes("borst") || focus.includes("chest")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR BORST DAG:
          - Gebruik UITSLUITEND borstoefeningen (spier: 'Borst').
          - Absoluut geen andere grote spiergroepen (Rug, Schouders, Biceps, Triceps, Benen).`;
        } else if (focus.includes("rug") || focus.includes("back")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR RUG DAG:
          - Gebruik UITSLUITEND rugoefeningen (spier: 'Rug' of 'Onderrug').
          - Absoluut geen borst, schouders, biceps, triceps of benen.`;
        } else if (focus.includes("schouders") || focus.includes("shoulder")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR SCHOUDERS DAG:
          - Gebruik UITSLUITEND schouderoefeningen (spier: 'Schouders').
          - Absoluut geen borst, rug, biceps, triceps of benen.`;
        } else if (focus.includes("arm")) {
          muscleSplitRule = `
STRENGE VERPLICHTING VOOR ARMEN DAG:
          - Gebruik UITSLUITEND armoefeningen (spier: 'Biceps' of 'Triceps').
          - Absoluut geen borst, rug, schouders of benen.`;
        }
      }
      let candidateExercisesRule = "";
      if (!isRestDay) {
        const muscleCategories = getMuscleCategoriesForFocus(sessionName);
        const isConditieGoal = (userModel.goal || "").toLowerCase().includes("conditie") || (userModel.goal || "").toLowerCase().includes("vetverlies");
        const strengthCandidates = getCandidateExercises(muscleCategories, userModel.equipment, "strength", 20);
        const cardioCandidates = isConditieGoal ? getCandidateExercises([], userModel.equipment, "cardio", 8, false) : [];
        if (strengthCandidates.length > 0) {
          candidateExercisesRule = `
GEVERIFIEERDE OEFENINGEN-LIJST (gebruik bij voorkeur namen uit deze lijst, gefilterd op jouw spiergroep-focus en apparatuur):
          ${strengthCandidates.join(", ")}
          - Wijk hier alleen van af als geen enkele optie logisch past bij de exacte spiergroep-eis of apparatuur-beperking hierboven.${cardioCandidates.length > 0 ? `
          - Voor de verplichte cardio-blokken, kies bij voorkeur uit: ${cardioCandidates.join(", ")}.` : ""}`;
        }
      }
      let painRule = "";
      if (painNotes.length > 0) {
        painRule = `
ABSOLUTE VEILIGHEIDSREGEL (OVERSCHRIJFT ALLE ANDERE REGELS):
        - De gebruiker heeft de volgende pijnpunten/blessures gemeld: ${painNotes.join(", ")}.
        - Vermijd VOLLEDIG elke oefening die deze regio belast of kan verergeren, ook als dat betekent dat je afwijkt van de normale spiergroep-verdeling voor deze sessie.
        - Kies een veilig alternatief binnen een vergelijkbare spiergroep-categorie. Voeg geen oefening toe waarbij je twijfelt over de veiligheid.
        - Dit is geen suggestie maar een harde grens.`;
      }
      const goalRule = !isRestDay ? buildGoalRule(userModel.goal, numberOfExercises, userModel.equipment) : "";
      const volumeRule = !isRestDay ? buildVolumeBudgetRule(metrics) : "";
      let beginnerRule = "";
      const expLevel = baseline?.experienceLevel;
      if (!isRestDay && expLevel === "beginner") {
        beginnerRule = `
STRENGE VERPLICHTING VOOR BEGINNERS:
        - Kies bewezen, stabiele basisoefeningen (machines of begeleide compound-bewegingen) boven complexe vrije-gewicht- of unilaterale varianten.
        - Wees conservatief met 'targetWeight': onderschatten is veiliger dan overschatten terwijl iemand de vorm nog leert.
        - Vermijd geavanceerde technieken (drop sets, rest-pause, super sets) volledig.`;
      } else if (!isRestDay && expLevel === "intermediate") {
        beginnerRule = `
STRENGE VERPLICHTING VOOR GEMIDDELD NIVEAU:
        - Vrije gewichten EN machines zijn beide toegestaan, normale oefening-complexiteit.
        - Geen geavanceerde intensiteitstechnieken nodig \u2014 focus op consistente, gestage progressieve overload.`;
      } else if (!isRestDay && expLevel === "advanced") {
        beginnerRule = `
STRENGE VERPLICHTING VOOR GEVORDERDEN:
        - Complexere, technische vrije-gewicht-bewegingen (bijv. unilaterale varianten, geavanceerde compound-lifts) zijn toegestaan en aanbevolen boven machines, mits de apparatuur het toelaat.
        - E\xE9n enkele drop set of rest-pause set op de LAATSTE oefening van de sessie is toegestaan voor extra intensiteit (niet op de hoofdoefening die onder progressieve overload staat).
        - Kies het hogere eind van de sets-richtlijn voor het gekozen doel \u2014 deze gebruiker heeft een hogere volumetolerantie.`;
      }
      let stabilityRule = "";
      let progressionRule = "";
      const plateauedLifts = !isRestDay ? detectPlateaus(history, sessionName) : [];
      const currentBlock = computeBlockNumber(baseline);
      const prescribedWeights = {};
      let isNewBlock = false;
      if (!isRestDay && Array.isArray(history)) {
        const previousSession = history.find(
          (s) => sessionNamesMatch(s?.name, sessionName)
        );
        const previousSessionBlock = computeBlockNumber(baseline, previousSession?.timestamp);
        isNewBlock = !!baseline?.completedAt && !!previousSession?.timestamp && previousSessionBlock !== currentBlock;
        const previousMainLifts = (previousSession?.exercises || []).slice(0, 2).map((e) => e.name).filter(Boolean);
        if (previousMainLifts.length > 0 && isNewBlock) {
          stabilityRule = `
STRENGE VERPLICHTING VOOR BLOK-ROTATIE (nieuw periodiseringsblok, elke 4 weken):
          - Er is een nieuw trainingsblok begonnen (blok ${currentBlock}). De hoofdoefeningen van het vorige blok waren: ${previousMainLifts.join(", ")}.
          - Kies voor de hoofdoefeningen bewust EEN ANDERE, vergelijkbare variant voor dezelfde spiergroep en beweegfunctie (bijv. Barbell Bench Press \u2192 Dumbbell Bench Press, of Back Squat \u2192 Front Squat / Hack Squat) \u2014 niet exact dezelfde naam.
          - Leg in de 'executionCue' van deze oefening kort uit dat dit een bewuste wisseling is voor een nieuwe prikkel na 4 weken, bijv. "Nieuw blok: we wisselen naar deze variant om je gewrichten te ontlasten en een nieuwe groeiprikkel te geven."
          - De progressie-teller begint voor deze nieuwe oefening opnieuw (geen 'vorig gewicht' beschikbaar, schat een realistisch startgewicht op basis van de nulmeting).`;
        } else if (previousMainLifts.length > 0) {
          stabilityRule = `
STRENGE VERPLICHTING VOOR PROGRESSIEVE OVERLOAD (blok ${currentBlock}, geen wisseling):
          - Vorige keer dat je een '${sessionName}' sessie genereerde, koos je als hoofdoefeningen: ${previousMainLifts.join(", ")}.
          - Je MOET deze exacte oefeningen herhalen (zelfde naam), zodat gewichtsprogressie trackbaar blijft, BEHALVE als ze op de dislikes-lijst staan.
          - Alleen de overige (accessoire) oefeningen mogen wisselen voor afwisseling.`;
        }
        if (previousMainLifts.length > 0 && !isNewBlock) {
          const matchingSessionsForWeights = history.filter(
            (s) => sessionNamesMatch(s?.name, sessionName)
          );
          const weightLines = (previousSession?.exercises || []).slice(0, 2).filter((e) => e?.name && typeof e?.topWeight === "number" && e.topWeight > 0).map((e) => {
            if (plateauedLifts.includes(e.name)) {
              const reducedWeight = Math.round(e.topWeight * 0.9 * 2) / 2;
              prescribedWeights[e.name.toLowerCase().trim()] = reducedWeight;
              return `- '${e.name}': PLATEAU GEDETECTEERD (3x op rij 'Maximaal' zonder progressie). Gebruik EXACT ${reducedWeight}kg als targetWeight (10% lichter dan de vorige ${e.topWeight}kg) om het plateau te doorbreken. Vermeld dit kort en eerlijk in de 'executionCue' van deze oefening (bijv. "We doorbreken het plateau: iets lichter vandaag om je lichaam een nieuwe prikkel te geven.").`;
            }
            const recentIntensities = matchingSessionsForWeights.slice(0, 2).map((s) => (s?.exercises || []).find((ex) => ex?.name === e.name)?.intensity).filter(Boolean);
            const nextWeight = computeProgressedWeight(e.topWeight, e.intensity, recentIntensities);
            prescribedWeights[e.name.toLowerCase().trim()] = nextWeight;
            const fastTrack = recentIntensities.length >= 2 && recentIntensities.slice(0, 2).every((i) => i === "Makkelijk");
            return `- '${e.name}': vorige topWeight ${e.topWeight}kg, intensiteit '${e.intensity || "onbekend"}' \u2192 gebruik EXACT ${nextWeight}kg als targetWeight.${fastTrack ? " (versnelde correctie: 2x op rij Makkelijk gerapporteerd)" : ""}`;
          });
          if (weightLines.length > 0) {
            progressionRule = `
STRENGE VERPLICHTING VOOR GEWICHTSPROGRESSIE (deterministisch, niet zelf inschatten):
          ${weightLines.join("\n          ")}
          - Voor alle ANDERE oefeningen (zonder voorgeschreven gewicht hierboven) mag je nog steeds een realistisch gewicht inschatten op basis van de nulmeting en geschiedenis.`;
          }
        }
      }
      let deloadRule = "";
      if (isDeloadWeek) {
        deloadRule = `
STRENGE VERPLICHTING VOOR DELOAD-WEEK:
        - Dit is een geplande deload-week (elke 6 weken). Verlaag het aantal sets per oefening met ongeveer 40-50% t.o.v. een normale week (bijv. 4 sets wordt 2, 3 sets wordt 2).
        - Houd het gewicht ('targetWeight') wel op het normale niveau \u2014 alleen het volume gaat omlaag, niet de intensiteit.${isNewBlock ? " UITZONDERING: dit is ook toevallig de start van een nieuw periodiseringsblok, dus er is geen 'normaal niveau' voor de nieuwe hoofdoefening-variant \u2014 schat voor die specifieke oefening een conservatief startgewicht, in lijn met de blok-rotatie-instructie hierboven." : ""}
        - Het AANTAL oefeningen blijft exact ${numberOfExercises}.`;
      }
      const systemPrompt = isRestDay ? `Jij bent Aura, de AI fitness coach van ${userModel.name || "Gebruiker"}.
        Sessie focus: Yoga & Actief Herstel (Rustdag).${muscleSplitRule}${painRule}
        STRENGE REGELS:
        1. De gebruiker is herstellende van eerdere zware workouts. Genereer absoluut GEEN gewichtheffen, fitness of krachttraining.
        2. Voorkeuren: Likes = ${JSON.stringify(prefs?.likes || [])}, Dislikes = ${JSON.stringify(prefs?.dislikes || [])}. Geef vaker likes en NOOIT dislikes.
        3. Genereer exact ${numberOfExercises} yoga poses of stretch oefeningen.
        4. Omdat dit yoga is, MOET het startgewicht ('targetWeight') voor elke oefening 0 kg zijn.
        5. De apparatuur ('equip') moet altijd 'Yoga mat' of 'Lichaamsgewicht' zijn.
        6. Geef voor elke pose een 'executionCue' (max 2 zinnen): waar in het lichaam de stretch/spanning gevoeld moet worden, en hoe te ademen tijdens de houding. Voorbeeld: "Laat je heupen zakken richting de mat en adem diep in je onderrug \u2014 voel de rek in je hamstrings, niet in je onderrug." Geen vage taal zoals 'voel je goed'.

        Genereer een lijst met yoga/stretch oefeningen in JSON-formaat.` : `Jij bent Aura, de AI fitness coach van ${userModel.name || "Gebruiker"}. Doel: ${userModel.goal || "Hypertrofie"}.
        Sessie focus: ${sessionName}.${painRule}${baselinePrompt}${muscleSplitRule}${candidateExercisesRule}${beginnerRule}${goalRule}${volumeRule}${stabilityRule}${progressionRule}${deloadRule}
        STRENGE REGELS:
        1. Apparatuurlijst van gebruiker: ${JSON.stringify(userModel.equipment || [])}. Gebruik UITSLUITEND oefeningen die EXACT met deze materialen kunnen worden uitgevoerd. Geef in het 'equip' veld aan welke apparatuur gebruikt wordt.
        2. Voorkeuren: Likes = ${JSON.stringify(prefs?.likes || [])}, Dislikes = ${JSON.stringify(prefs?.dislikes || [])}. Geef vaker likes en NOOIT dislikes.
        3. Herstel biometrie: ${JSON.stringify(metrics || {})}. Ontzie spieren die uitgeput zijn.
        4. Genereer exact ${numberOfExercises} hoofdoefeningen, PLUS verplicht \xE9\xE9n extra warming-up oefening als EERSTE item in de lijst (dus in totaal ${numberOfExercises + 1} items). De warming-up: naam 'Warming-up', muscle de hoofdspiergroep van de sessie of 'Cardio', equip passend bij beschikbare apparatuur, sets 1, reps '5-10 minuten', targetWeight 0, restSeconds 30, en een executionCue met een korte, specifieke opwarmroutine die aansluit op de eerste hoofdoefening (bijv. lichte cardio plus 1-2 losse herhalingen met laag gewicht).
        5. Geef voor elke oefening een re\xEBel startgewicht ('targetWeight') in kg op basis van de eerdere geschiedenis: ${JSON.stringify(history || [])} en bovenstaande nulmeting. Als een oefening nieuw is, schat dan een veilig startgewicht in dat perfect aansluit bij de nulmeting.
        6. Sorteer de oefeningen van meest samengesteld/multi-joint (bijv. squat, bench press, rij) naar meest ge\xEFsoleerd/single-joint (bijv. bicep curl, calf raise) \u2014 de zwaarste, meest technische oefening MOET eerst komen terwijl de gebruiker fris is (de warming-up uit regel 4 blijft uiteraard altijd als allereerste).
        7. Geef voor elke oefening een 'restSeconds' op volgens de doel-specifieke rusttijd hierboven.
        8. Geef voor elke oefening een 'executionCue' (max 2 zinnen): HOE de beweging technisch correct wordt uitgevoerd (tempo, gewrichtspositie, ademhaling) \xE9n WAAR de gebruiker mentaal op moet letten (welke spier moet je voelen, welke fout vermijden). Voorbeeld: "Houd je ellebogen dicht bij je lichaam en voel de spanning in je triceps bij het neerlaten \u2014 vermijd dat je schouders mee omhoog komen." Geen vage taal zoals 'let op je vorm'.
        
        STRENGE CONTROLE: Controleer of ELKE gegenereerde HOOFDoefening (dus exclusief de warming-up) voldoet aan de hierboven gedefinieerde spiergroep-beperkingen voor de huidige trainingsfocus. De warming-up (muscle 'Cardio' of de sessie-hoofdspiergroep) telt niet als overtreding van deze regel. Leg day mag GEEN borst, armen of schouders bevatten! Full Body MOET exact \xE9\xE9n oefening per hoofdcategorie hebben!

        Genereer een lijst met oefeningen in JSON-formaat.`;
      const response = await generateContentWithFallback(ai, {
        contents: systemPrompt,
        primaryModel: "gemini-3.5-flash",
        config: {
          temperature: 0.2,
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.ARRAY,
            items: {
              type: import_genai.Type.OBJECT,
              properties: {
                name: {
                  type: import_genai.Type.STRING,
                  description: "Naam van de oefening in het Nederlands of gangbare fitness term"
                },
                muscle: {
                  type: import_genai.Type.STRING,
                  description: "Primaire spiergroep: Borst, Bovenrug, Onderrug, Schouders, Biceps, Triceps, Quadriceps, Hamstrings, Gluten, Kuiten of Core"
                },
                equip: {
                  type: import_genai.Type.STRING,
                  description: "De benodigde apparatuur of spullen, specifiek en compleet (bijv. 'Barbell + bankje', 'Yoga mat + blok', niet alleen 'Machine')"
                },
                sets: {
                  type: import_genai.Type.INTEGER,
                  description: "Aantal sets (meestal 3 of 4)"
                },
                reps: {
                  type: import_genai.Type.STRING,
                  description: "Rep range of reps richtlijn (bijv. '8-10', '10-12', '12-15')"
                },
                targetWeight: {
                  type: import_genai.Type.NUMBER,
                  description: "Veilig startgewicht of verhoogd overload gewicht in kg"
                },
                restSeconds: {
                  type: import_genai.Type.INTEGER,
                  description: "Aanbevolen rusttijd tussen sets in seconden, volgens de doel-specifieke regel (bijv. 60-90 voor hypertrofie, 120-180 voor kracht)"
                },
                executionCue: {
                  type: import_genai.Type.STRING,
                  description: "Concrete uitvoerings- en focus-tip in maximaal 2 zinnen: HOE de beweging/pose technisch correct wordt uitgevoerd (tempo, houding, ademhaling) \xE9n WAAR mentaal op gelet moet worden (welke spier of lichaamsdeel je moet voelen, welke fout te vermijden). Geen vage algemeenheden zoals 'let op je vorm' \u2014 altijd specifiek en lichaamsdeel-gericht."
                }
              },
              required: ["name", "muscle", "equip", "sets", "reps", "targetWeight", "restSeconds", "executionCue"]
            }
          }
        }
      });
      let text = response.text;
      if (!text) {
        throw new Error("Leeg antwoord ontvangen van AI.");
      }
      text = text.replace(/```json/gi, "").replace(/```/g, "").trim();
      const parsedExercises = JSON.parse(text);
      const weightEnforced = enforcePrescribedWeights(parsedExercises, prescribedWeights);
      console.log("[AURA DEBUG]", JSON.stringify({
        sessionName,
        currentBlock,
        isNewBlock,
        isDeloadWeek,
        blockAndDeloadOverlap: isDeloadWeek && isNewBlock,
        plateauedLifts,
        prescribedWeightsApplied: prescribedWeights
      }));
      res.json(enrichExercisesWithImages(weightEnforced));
    } catch (error) {
      console.log("[AURA AI] Notice: Offline schedule generator engaged. Activating personalized offline database...");
      res.json({ error: "QUOTA_EXHAUSTED", message: error.message || "Quota limiet bereikt", data: [] });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
//# sourceMappingURL=server.cjs.map
