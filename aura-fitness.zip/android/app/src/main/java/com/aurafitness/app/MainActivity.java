package com.aurafitness.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
