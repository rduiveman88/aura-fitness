/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { FatigueInfo, MuscleGroup, UserModel } from '../types';
import { AlertTriangle } from 'lucide-react';

interface BodyDiagramProps {
  fatigue: Record<MuscleGroup, FatigueInfo>;
  onSelectGroup?: (group: MuscleGroup | null) => void;
  isRestDay?: boolean;
  userModel?: UserModel;
}

// Highly detailed SVG polygon data adapted from body-highlighter
const anteriorMuscles = [
  {
    group: 'chest' as MuscleGroup,
    label: 'Borstspieren (Chest)',
    svgPoints: [
      '51.8367347 41.6326531 51.0204082 55.1020408 57.9591837 57.9591837 67.755102 55.5102041 70.6122449 47.3469388 62.0408163 41.6326531 ',
      '29.7959184 46.5306122 31.4285714 55.5102041 40.8163265 57.9591837 48.1632653 55.1020408 47.755102 42.0408163 37.5510204 42.0408163',
    ],
  },
  {
    group: 'core' as MuscleGroup,
    label: 'Schuine Buikspieren (Obliques)',
    svgPoints: [
      '68.5714286 63.2653061 67.3469388 57.1428571 58.7755102 59.5918367 60 64.0816327 60.4081633 83.2653061 65.7142857 78.7755102 66.5306122 69.7959184',
      '33.877551 78.3673469 33.0612245 71.8367347 31.0204082 63.2653061 32.244898 57.1428571 40.8163265 59.1836735 39.1836735 63.2653061 39.1836735 83.6734694',
    ],
  },
  {
    group: 'core' as MuscleGroup,
    label: 'Buikspieren (Abs)',
    svgPoints: [
      '56.3265306 59.1836735 57.9591837 64.0816327 58.3673469 77.9591837 58.3673469 92.6530612 56.3265306 98.3673469 55.1020408 104.081633 51.4285714 107.755102 51.0204082 84.4897959 50.6122449 67.3469388 51.0204082 57.1428571',
      '43.6734694 58.7755102 48.5714286 57.1428571 48.9795918 67.3469388 48.5714286 84.4897959 48.1632653 107.346939 44.4897959 103.673469 40.8163265 91.4285714 40.8163265 78.3673469 41.2244898 64.4897959',
    ],
  },
  {
    group: 'biceps' as MuscleGroup,
    label: 'Biceps',
    svgPoints: [
      '16.7346939 68.1632653 17.9591837 71.4285714 22.8571429 66.122449 28.9795918 53.877551 27.755102 49.3877551 20.4081633 55.9183673',
      '71.4285714 49.3877551 70.2040816 54.6938776 76.3265306 66.122449 81.6326531 71.8367347 82.8571429 68.9795918 78.7755102 55.5102041',
    ],
  },
  {
    group: 'triceps' as MuscleGroup,
    label: 'Triceps',
    svgPoints: [
      '69.3877551 55.5102041 69.3877551 61.6326531 75.9183673 72.6530612 77.5510204 70.2040816 75.5102041 67.3469388',
      '22.4489796 69.3877551 29.7959184 55.5102041 29.7959184 60.8163265 22.8571429 73.0612245',
    ],
  },
  {
    group: 'shoulders' as MuscleGroup,
    label: 'Voorkant Schouders (Deltoids)',
    svgPoints: [
      '78.3673469 53.0612245 79.5918367 47.755102 79.1836735 41.2244898 75.9183673 37.9591837 71.0204082 36.3265306 72.244898 42.8571429 71.4285714 47.3469388',
      '28.1632653 47.3469388 21.2244898 53.0612245 20 47.755102 20.4081633 40.8163265 24.4897959 37.1428571 28.5714286 37.1428571 26.9387755 43.2653061',
    ],
  },
  {
    group: 'quadriceps' as MuscleGroup,
    label: 'Bovenbenen (Quadriceps)',
    svgPoints: [
      '32.244898 94.6938776 29.3877551 100.816327 28.1632653 111.428571 29.3877551 120 31.0204082 132.653061 34.2857143 137.142857 37.1428571 127.755102 37.1428571 108.163265 34.6938776 98.7755102',
      '63.2653061 105.714286 62.0408163 111.428571 62.4489796 128.571429 65.3061224 137.55102 68.1632653 133.061224 71.0204082 111.836735 70.2040816 101.22449 66.9387755 94.6938776 64.4897959 100',
      '38.7755102 129.387755 38.3673469 112.244898 41.2244898 118.367347 44.4897959 129.387755 42.8571429 135.102041 40 146.122449 36.3265306 146.530612 35.5102041 140',
      '59.5918367 145.714286 62.8571429 146.530612 64.0816327 139.591837 61.2244898 130.204082 60.8163265 113.877551 55.5102041 128.979592',
      '32.6530612 138.367347 29.3877551 133.469388 26.9387755 114.285714 25.7142857 127.346939 25.7142857 136.734694 26.5306122 145.714286',
      '71.8367347 113.061224 70.2040816 133.469388 66.5306122 138.367347 72.6530612 145.714286 73.877551 140.408163 73.877551 124.081633',
    ],
  },
  {
    group: 'calves' as MuscleGroup,
    label: 'Kuitspieren (Calves)',
    svgPoints: [
      '71.4285714 160.408163 73.4693878 153.469388 76.7346939 161.22449 79.5918367 167.755102 78.3673469 187.755102 79.5918367 195.510204 74.6938776 195.510204',
      '24.8979592 194.693878 27.755102 164.897959 28.1632653 160.408163 26.122449 154.285714 24.8979592 157.55102 22.4489796 161.632653 20.8163265 167.755102 22.0408163 188.163265 20.8163265 195.510204',
      '72.6530612 195.102041 69.7959184 159.183673 65.3061224 158.367347 64.0816327 162.44898 64.0816327 165.306122 65.7142857 177.142857',
      '35.5102041 158.367347 35.9183673 162.44898 35.9183673 166.938776 35.1020408 172.244898 35.1020408 176.734694 32.244898 182.040816 30.6122449 187.346939 26.9387755 194.693878 27.3469388 187.755102 28.1632653 180.408163 28.5714286 175.510204 28.9795918 169.795918 29.7959184 164.081633 30.2040816 158.77551',
    ],
  },
  {
    group: 'forearms' as MuscleGroup,
    label: 'Onderarmen (Forearms)',
    svgPoints: [
      '6.12244898 88.5714286 10.2040816 75.1020408 14.6938776 70.2040816 16.3265306 74.2857143 19.1836735 73.4693878 4.48979592 97.5510204 0 100',
      '84.4897959 69.7959184 83.2653061 73.4693878 80 73.0612245 95.1020408 98.3673469 100 100.408163 93.4693878 89.3877551 89.7959184 76.3265306',
      '77.5510204 72.244898 77.5510204 77.5510204 80.4081633 84.0816327 85.3061224 89.7959184 92.244898 101.22449 94.6938776 99.5918367',
      '6.93877551 101.22449 13.4693878 90.6122449 18.7755102 84.0816327 21.6326531 77.1428571 21.2244898 71.8367347 4.89795918 98.7755102',
    ],
  },
  // Neutral aesthetic shapes (Non-clickable body parts for front)
  {
    group: null,
    label: 'Nek / Hoofd / Gewrichten',
    svgPoints: [
      // Head
      '42.4489796 2.85714286 40 11.8367347 42.0408163 19.5918367 46.122449 23.2653061 49.7959184 25.3061224 54.6938776 22.4489796 57.5510204 19.1836735 59.1836735 10.2040816 57.1428571 2.44897959 49.7959184 0',
      // Neck
      '55.5102041 23.6734694 50.6122449 33.4693878 50.6122449 39.1836735 61.6326531 40 70.6122449 44.8979592 69.3877551 36.7346939 63.2653061 35.1020408 58.3673469 30.6122449',
      '28.9795918 44.8979592 30.2040816 37.1428571 36.3265306 35.1020408 41.2244898 30.2040816 44.4897959 24.4897959 48.9795918 33.877551 48.5714286 39.1836735 37.9591837 39.5918367',
      // Knees
      '33.877551 140 34.6938776 143.265306 35.5102041 147.346939 36.3265306 151.020408 35.1020408 156.734694 29.7959184 156.734694 27.3469388 152.653061 27.3469388 147.346939 30.2040816 144.081633',
      '65.7142857 140 72.244898 147.755102 72.244898 152.244898 69.7959184 157.142857 64.8979592 156.734694 62.8571429 151.020408',
      // Abductors
      '52.6530612 110.204082 54.2857143 124.897959 60 110.204082 62.0408163 100 64.8979592 94.2857143 60 92.6530612 56.7346939 104.489796',
      '47.755102 110.612245 44.8979592 125.306122 42.0408163 115.918367 40.4081633 113.061224 39.5918367 107.346939 37.9591837 102.44898 34.6938776 93.877551 39.5918367 92.244898 41.6326531 99.1836735 43.6734694 105.306122',
    ]
  }
];

const posteriorMuscles = [
  {
    group: 'back' as MuscleGroup,
    label: 'Monnikskapspier (Trapezius)',
    svgPoints: [
      '44.6808511 21.7021277 47.6595745 21.7021277 47.2340426 38.2978723 47.6595745 64.6808511 38.2978723 53.1914894 35.3191489 40.8510638 31.0638298 36.5957447 39.1489362 33.1914894 43.8297872 27.2340426',
      '52.3404255 21.7021277 55.7446809 21.7021277 56.5957447 27.2340426 60.8510638 32.7659574 68.9361702 36.5957447 64.6808511 40.4255319 61.7021277 53.1914894 52.3404255 64.6808511 53.1914894 38.2978723',
    ],
  },
  {
    group: 'back' as MuscleGroup,
    label: 'Brede Rugspier (Lats / Upper Back)',
    svgPoints: [
      '31.0638298 38.7234043 28.0851064 48.9361702 28.5106383 55.3191489 34.0425532 75.3191489 47.2340426 71.0638298 47.2340426 66.3829787 36.5957447 54.0425532 33.6170213 41.2765957',
      '68.9361702 38.7234043 71.9148936 49.3617021 71.4893617 56.1702128 65.9574468 75.3191489 52.7659574 71.0638298 52.7659574 66.3829787 63.4042553 54.4680851 66.3829787 41.7021277',
    ],
  },
  {
    group: 'shoulders' as MuscleGroup,
    label: 'Achterkant Schouders (Deltoids)',
    svgPoints: [
      '29.3617021 37.0212766 22.9787234 39.1489362 17.4468085 44.2553191 18.2978723 53.6170213 24.2553191 49.3617021 27.2340426 46.3829787',
      '71.0638298 37.0212766 78.2978723 39.5744681 82.5531915 44.6808511 81.7021277 53.6170213 74.893617 48.9361702 72.3404255 45.106383',
    ],
  },
  {
    group: 'triceps' as MuscleGroup,
    label: 'Triceps',
    svgPoints: [
      '26.8085106 49.787234 17.8723404 55.7446809 14.4680851 72.3404255 16.5957447 81.7021277 21.7021277 63.8297872 26.8085106 55.7446809',
      '73.6170213 50.212766 82.1276596 55.7446809 85.9574468 73.1914894 83.4042553 82.1276596 77.8723404 62.9787234 73.1914894 55.7446809',
      '26.8085106 58.2978723 26.8085106 68.5106383 22.9787234 75.3191489 19.1489362 77.4468085 22.5531915 65.5319149',
      '72.7659574 58.2978723 77.0212766 64.6808511 80.4255319 77.4468085 76.5957447 75.3191489 72.7659574 68.9361702',
    ],
  },
  {
    group: 'lowerback' as MuscleGroup,
    label: 'Onderrug (Lower Back)',
    svgPoints: [
      '47.6595745 72.7659574 34.4680851 77.0212766 35.3191489 83.4042553 49.3617021 102.12766 46.8085106 82.9787234',
      '52.3404255 72.7659574 65.5319149 77.0212766 64.6808511 83.4042553 50.6382979 102.12766 53.1914894 83.8297872',
    ],
  },
  {
    group: 'glutes' as MuscleGroup,
    label: 'Gluteus (Gluten / Billen)',
    svgPoints: [
      '44.6808511 99.5744681 30.212766 108.510638 29.787234 118.723404 31.4893617 125.957447 47.2340426 121.276596 49.3617021 114.893617',
      '55.3191489 99.1489362 51.0638298 114.468085 52.3404255 120.851064 68.0851064 125.957447 69.787234 119.148936 69.3617021 108.510638',
    ],
  },
  {
    group: 'hamstrings' as MuscleGroup,
    label: 'Achterkant Bovenbenen (Hamstrings)',
    svgPoints: [
      '28.9361702 122.12766 31.0638298 129.361702 36.5957447 125.957447 35.3191489 135.319149 34.4680851 150.212766 29.3617021 158.297872 28.9361702 146.808511 27.6595745 141.276596 27.2340426 131.489362',
      '71.4893617 121.702128 69.3617021 128.93617 63.8297872 125.957447 65.5319149 136.595745 66.3829787 150.212766 71.0638298 158.297872 71.4893617 147.659574 72.7659574 142.12766 73.6170213 131.914894',
      '38.7234043 125.531915 44.2553191 145.957447 40.4255319 166.808511 36.1702128 152.765957 37.0212766 135.319149',
      '61.7021277 125.531915 63.4042553 136.170213 64.2553191 153.191489 60 166.808511 56.1702128 146.382979',
    ],
  },
  {
    group: 'calves' as MuscleGroup,
    label: 'Kuitspieren (Calves)',
    svgPoints: [
      '29.3617021 160.425532 28.5106383 167.234043 24.6808511 179.574468 23.8297872 192.765957 25.5319149 197.021277 28.5106383 193.191489 29.787234 180 31.9148936 171.06383 31.9148936 166.808511',
      '37.4468085 165.106383 35.3191489 167.659574 33.1914894 171.914894 31.0638298 180.425532 30.212766 191.914894 34.0425532 200 38.7234043 190.638298 39.1489362 168.93617',
      '62.9787234 165.106383 61.2765957 168.510638 61.7021277 190.638298 66.3829787 199.574468 70.6382979 191.914894 68.9361702 179.574468 66.8085106 170.212766',
      '70.6382979 160.425532 72.3404255 168.510638 75.7446809 179.148936 76.5957447 192.765957 74.4680851 196.595745 72.3404255 193.617021 70.6382979 179.574468 68.0851064 168.085106',
      // Soleus
      '28.5106383 195.744681 30.212766 195.744681 33.6170213 201.702128 30.6382979 220 28.5106383 213.617021 26.8085106 198.297872',
      '69.787234 195.744681 71.9148936 195.744681 73.6170213 198.297872 71.9148936 213.191489 70.212766 219.574468 67.2340426 202.12766',
    ],
  },
  {
    group: 'forearms' as MuscleGroup,
    label: 'Onderarmen (Forearms)',
    svgPoints: [
      '86.3829787 75.7446809 91.0638298 83.4042553 93.1914894 94.0425532 100 106.382979 96.1702128 104.255319 88.0851064 89.3617021 84.2553191 83.8297872',
      '13.6170213 75.7446809 8.93617021 83.8297872 6.80851064 93.6170213 0 106.382979 3.82978723 104.255319 12.3404255 88.5106383 15.7446809 82.9787234',
      '81.2765957 79.5744681 77.4468085 77.8723404 79.1489362 84.6808511 91.0638298 103.829787 93.1914894 108.93617 94.4680851 104.680851',
      '18.7234043 79.5744681 22.1276596 77.8723404 20.8510638 84.2553191 9.36170213 102.978723 6.80851064 108.510638 5.10638298 104.680851',
    ],
  },
  // Neutral aesthetic shapes (Non-clickable body parts for back)
  {
    group: null,
    label: 'Nek / Hoofd / Gewrichten',
    svgPoints: [
      // Head
      '50.6382979 0 45.9574468 0.85106383 40.8510638 5.53191489 40.4255319 12.7659574 45.106383 20 55.7446809 20 59.1489362 13.6170213 59.5744681 4.68085106 55.7446809 1.27659574',
      // Knees
      '34.4680851 153.191489 31.0638298 159.148936 33.6170213 166.382979 37.4468085 162.553191',
      '66.3829787 153.617021 62.9787234 162.978723 66.8085106 166.382979 69.3617021 159.148936',
      // Abductor
      '48.0851064 122.978723 44.6808511 122.978723 41.2765957 125.531915 45.106383 144.255319 48.5106383 135.744681 48.9361702 129.361702',
      '51.9148936 122.553191 55.7446809 123.404255 59.1489362 125.957447 54.893617 144.255319 51.9148936 136.170213 51.0638298 129.361702',
    ]
  }
];

const isMuscleGroupPainful = (group: MuscleGroup, painPoints: string[] = []): boolean => {
  if (!painPoints || painPoints.length === 0) return false;
  
  const lowerPoints = painPoints.map(p => p.toLowerCase());
  
  switch (group) {
    case 'quadriceps':
    case 'calves':
      return lowerPoints.some(p => p.includes('knie') || p.includes('leg') || p.includes('quad'));
    case 'shoulders':
      return lowerPoints.some(p => p.includes('schouder') || p.includes('shoulder') || p.includes('deltoid'));
    case 'lowerback':
      return lowerPoints.some(p => p.includes('onderrug') || p.includes('lowerback') || p.includes('rug') && !p.includes('bovenrug'));
    case 'back':
      return lowerPoints.some(p => p.includes('bovenrug') || p.includes('nek') || p.includes('back') && !p.includes('onderrug'));
    case 'forearms':
      return lowerPoints.some(p => p.includes('pols') || p.includes('elleboog') || p.includes('wrist') || p.includes('elbow') || p.includes('forearm'));
    case 'hamstrings':
      return lowerPoints.some(p => p.includes('hamstring') || p.includes('achterkant been'));
    case 'biceps':
    case 'triceps':
      return lowerPoints.some(p => p.includes('arm') || p.includes('bicep') || p.includes('tricep'));
    case 'chest':
      return lowerPoints.some(p => p.includes('borst') || p.includes('chest') || p.includes('pec'));
    case 'glutes':
      return lowerPoints.some(p => p.includes('glute') || p.includes('bil'));
    case 'core':
      return lowerPoints.some(p => p.includes('buik') || p.includes('abs') || p.includes('core'));
    default:
      return false;
  }
};

export default function BodyDiagram({ fatigue, onSelectGroup, isRestDay, userModel }: BodyDiagramProps) {
  const [side, setSide] = useState<'front' | 'back'>('front');
  const [activeGroup, setActiveGroup] = useState<MuscleGroup | null>(null);
  const [hoveredGroup, setHoveredGroup] = useState<MuscleGroup | null>(null);

  const getInterpolatedColor = (ratio: number, opacity: number) => {
    const startColor = isRestDay ? [56, 189, 248] : [16, 185, 129];
    const midColor = [245, 158, 11];
    const endColor = [239, 68, 68];
    
    let r, g, b;
    if (ratio <= 0.5) {
      const t = ratio / 0.5;
      r = Math.round(startColor[0] * (1 - t) + midColor[0] * t);
      g = Math.round(startColor[1] * (1 - t) + midColor[1] * t);
      b = Math.round(startColor[2] * (1 - t) + midColor[2] * t);
    } else {
      const t = Math.min(1.0, (ratio - 0.5) / 0.5);
      r = Math.round(midColor[0] * (1 - t) + endColor[0] * t);
      g = Math.round(midColor[1] * (1 - t) + endColor[1] * t);
      b = Math.round(midColor[2] * (1 - t) + endColor[2] * t);
    }
    
    return {
      fill: `rgba(${r}, ${g}, ${b}, ${opacity})`,
      stroke: `rgb(${r}, ${g}, ${b})`
    };
  };

  const getGroupColor = (group: MuscleGroup | null, ratio: number) => {
    if (!group) return 'rgba(255, 255, 255, 0.04)'; // Neutral background for unmappable parts
    return getInterpolatedColor(ratio, 0.7).fill;
  };

  const getGroupStroke = (group: MuscleGroup | null, ratio: number) => {
    if (!group) return 'rgba(255, 255, 255, 0.08)';
    return getInterpolatedColor(ratio, 1.0).stroke;
  };

  const handleGroupClick = (group: MuscleGroup | null) => {
    if (!group) return; // ignore neutral clicks
    const nextGroup = activeGroup === group ? null : group;
    setActiveGroup(nextGroup);
    if (onSelectGroup) {
      onSelectGroup(nextGroup);
    }
  };

  const groupLabels: Record<MuscleGroup, string> = {
    chest: 'Borstspieren (Chest)',
    back: 'Bovenrug & Lats (Back)',
    shoulders: 'Schouders (Shoulders)',
    biceps: 'Biceps (Armen voorzijde)',
    triceps: 'Triceps (Armen achterzijde)',
    quadriceps: 'Quadriceps (Bovenbeen voorzijde)',
    hamstrings: 'Hamstrings (Bovenbeen achterzijde)',
    glutes: 'Gluten (Billen / Gluteal)',
    calves: 'Kuiten & Soleus (Onderbenen)',
    core: 'Buikspieren (Abs & Obliques)',
    lowerback: 'Onderrug (Lower Back)',
    forearms: 'Onderarmen (Forearms)'
  };

  const currentMuscles = side === 'front' ? anteriorMuscles : posteriorMuscles;

  return (
    <div className={`relative w-full flex flex-col items-center bg-white/5 border ${isRestDay ? 'border-sky-500/20' : 'border-white/10'} rounded-3xl p-6 shadow-2xl backdrop-blur-md`}>
      {/* Side Toggle Buttons */}
      <div className="flex justify-between items-center w-full mb-4">
        <span className={`text-xs font-semibold uppercase tracking-wider ${isRestDay ? 'text-sky-400' : 'text-emerald-400'}`}>
          Biometrisch Herstel
        </span>
        <div className="flex bg-black/40 p-1 rounded-full border border-white/10">
          <button
            onClick={() => setSide('front')}
            className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-300 ${
              side === 'front'
                ? isRestDay
                  ? 'bg-sky-500/20 text-sky-400 shadow-md border border-sky-500/20'
                  : 'bg-emerald-500/20 text-emerald-400 shadow-md border border-emerald-500/20'
                : 'text-white/40 hover:text-white'
            }`}
          >
            Voorzijde
          </button>
          <button
            onClick={() => setSide('back')}
            className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-300 ${
              side === 'back'
                ? isRestDay
                  ? 'bg-sky-500/20 text-sky-400 shadow-md border border-sky-500/20'
                  : 'bg-emerald-500/20 text-emerald-400 shadow-md border border-emerald-500/20'
                : 'text-white/40 hover:text-white'
            }`}
          >
            Achterzijde
          </button>
        </div>
      </div>

      {/* Futuristic Anatomical bodybuilder model */}
      <div className="relative w-56 h-[26rem] my-2 border border-white/5 rounded-2xl bg-black/25 flex-shrink-0 select-none flex items-center justify-center p-2">
        {/* Glow ambient effects */}
        <div className={`absolute inset-0 bg-gradient-to-b from-transparent ${isRestDay ? 'via-sky-500/5' : 'via-emerald-500/5'} to-transparent pointer-events-none rounded-2xl`} />
        
        {/* SVG Drawing */}
        <svg className="w-full h-full" viewBox="0 0 100 220" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            {/* Glow for hovered muscle */}
            <filter id="glow-hover" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="1.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            {/* Glow for selected/active muscle */}
            <filter id="glow-active" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="3.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Render each highly detailed muscle group */}
          {currentMuscles.map((muscle) => {
            const hasGroup = !!muscle.group;
            const mFatigue = hasGroup ? fatigue[muscle.group!] || { ratio: 0 } : { ratio: 0 };
            const isPainful = hasGroup && isMuscleGroupPainful(muscle.group!, userModel?.painPoints);
            const color = isPainful
              ? 'rgba(245, 158, 11, 0.35)' // Warning Amber-Orange fill
              : getGroupColor(muscle.group, mFatigue.ratio);
            const strokeColor = isPainful
              ? '#f59e0b' // Solid Amber stroke
              : getGroupStroke(muscle.group, mFatigue.ratio);
            const isActive = hasGroup && activeGroup === muscle.group;
            const isHovered = hasGroup && hoveredGroup === muscle.group;

            return (
              <g 
                key={`${side}-${muscle.label}-${muscle.group || 'neutral'}`}
                className={hasGroup ? 'cursor-pointer' : ''}
                onClick={() => handleGroupClick(muscle.group)}
                onMouseEnter={() => hasGroup && setHoveredGroup(muscle.group)}
                onMouseLeave={() => hasGroup && setHoveredGroup(null)}
              >
                {muscle.svgPoints.map((points, idx) => (
                  <polygon
                    key={idx}
                    points={points}
                    style={{
                      fill: color,
                      stroke: isActive ? '#ffffff' : isHovered ? strokeColor : isPainful ? '#f59e0b' : 'rgba(255, 255, 255, 0.08)',
                      strokeWidth: isActive ? 2.0 : isHovered ? 1.2 : isPainful ? 1.0 : 0.6,
                      filter: isActive ? 'url(#glow-active)' : isHovered ? 'url(#glow-hover)' : 'none',
                    }}
                    className={`transition-all duration-300 ${isPainful ? 'animate-[pulse_2.5s_infinite_ease-in-out]' : ''}`}
                  />
                ))}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Floating recovery score overlay positioned on the side */}
      {(hoveredGroup || activeGroup) && (
        <div className="absolute top-20 right-6 bg-black/95 border border-white/20 px-3.5 py-2 rounded-2xl shadow-2xl backdrop-blur-md transition-all duration-300 animate-fadeIn pointer-events-none flex flex-col items-center z-30">
          <span className="text-[9px] text-white/50 uppercase tracking-widest font-semibold">
            {(hoveredGroup || activeGroup || 'chest') === 'core' ? 'Core' : groupLabels[hoveredGroup || activeGroup || 'chest'].split(' ')[0]}
          </span>
          <span 
            className="text-lg font-mono font-bold" 
            style={{ color: getGroupStroke(hoveredGroup || activeGroup, fatigue[hoveredGroup || activeGroup || 'chest']?.ratio || 0) }}
          >
            {Math.round((1 - (fatigue[hoveredGroup || activeGroup || 'chest']?.ratio || 0)) * 100)}%
          </span>
        </div>
      )}

      {/* Selected Muscle Group Detail Panel */}
      <div className="w-full mt-4 border-t border-white/10 pt-4">
        {activeGroup ? (
          <div className="bg-black/20 rounded-2xl p-4 border border-white/5 animate-fadeIn">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className={`text-sm font-semibold ${isRestDay ? 'text-sky-400' : 'text-emerald-400'} mb-0.5`}>
                  {groupLabels[activeGroup]}
                </h4>
                <span className="text-[10px] text-white/40 uppercase tracking-wider font-mono">
                  Biometrische Focuszone
                </span>
              </div>
              {isMuscleGroupPainful(activeGroup, userModel?.painPoints) ? (
                <span
                  className="text-xs font-bold border border-amber-500/20 px-2.5 py-0.5 rounded-lg bg-amber-500/5 text-amber-400"
                  style={{
                    boxShadow: `0 0 10px rgba(245, 158, 11, 0.15)`
                  }}
                >
                  Beschermd / Gevoelig
                </span>
              ) : (
                <span
                  className="text-sm font-mono font-bold border border-white/10 px-2.5 py-0.5 rounded-lg bg-white/5"
                  style={{
                    color: getGroupStroke(activeGroup, fatigue[activeGroup]?.ratio || 0),
                    boxShadow: `0 0 10px ${getGroupColor(activeGroup, fatigue[activeGroup]?.ratio || 0)}`
                  }}
                >
                  {Math.round((1 - (fatigue[activeGroup]?.ratio || 0)) * 100)}% hersteld
                </span>
              )}
            </div>
            
            {/* Custom progress bar */}
            <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mb-3">
              <div 
                style={{ 
                  width: isMuscleGroupPainful(activeGroup, userModel?.painPoints) ? '100%' : `${Math.round((1 - (fatigue[activeGroup]?.ratio || 0)) * 100)}%`,
                  backgroundColor: isMuscleGroupPainful(activeGroup, userModel?.painPoints) ? '#f59e0b' : getGroupStroke(activeGroup, fatigue[activeGroup]?.ratio || 0)
                }}
                className={`h-full rounded-full transition-all duration-500 ${isMuscleGroupPainful(activeGroup, userModel?.painPoints) ? 'animate-pulse' : ''}`}
              />
            </div>

            <p className="text-[11px] text-white/70 leading-relaxed font-light">
              {isMuscleGroupPainful(activeGroup, userModel?.painPoints)
                ? 'Deze zone is gemarkeerd als gevoelig. Aura past de intensiteit en het volume automatisch aan en vermijdt zwaar belastende oefeningen om herstel te ondersteunen.'
                : fatigue[activeGroup]?.ratio >= 0.6
                ? 'Deze spiergroep is zwaar belast en nog vermoeid. Geef het voldoende rust of kies voor actieve hersteltraining.'
                : fatigue[activeGroup]?.ratio >= 0.25
                ? 'De spieren zijn herstellende en bijna klaar voor hernieuwde krachttraining. Ideaal voor gematigde belasting.'
                : 'Optimaal hersteld! Deze spiergroep is 100% klaar om maximaal belast te worden met progressive overload.'}
            </p>

            {isMuscleGroupPainful(activeGroup, userModel?.painPoints) && (
              <div className="mt-3 bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex gap-2.5 items-start animate-fadeIn">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="flex flex-col gap-0.5">
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">Gevoelige Zone</span>
                  <span className="text-[10px] text-white/70 leading-relaxed font-light block">
                    Gemarkeerd als gevoelig/geblesseerd ({userModel?.painPoints.filter(p => isMuscleGroupPainful(activeGroup, [p])).join(', ')}). Aura past trainingsvolumes aan en vervangt zware oefeningen automatisch om deze zone te ontlasten.
                  </span>
                </div>
              </div>
            )}
          </div>
        ) : (
          <p className="text-[10px] text-white/40 text-center italic">
            Klik op een spiergroep op het diagram of de gekleurde zones voor gedetailleerde herstelinfo.
          </p>
        )}
      </div>
    </div>
  );
}
